using Microsoft.AspNetCore.Mvc;
using System;
namespace Results
{
    public class ResultsController : Controller
    {
        // [HttpGet("results")]

        // public ViewResult Home()
        // {
        //     // Console.WriteLine(ViewBag.name);
        //     return View("Result");
        // }
    }
}